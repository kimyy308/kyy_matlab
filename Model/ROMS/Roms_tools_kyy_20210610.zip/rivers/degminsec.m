function degminsec(deg,min,sec,deg2,min2,sec2)
    value1=deg + min/60.0 + sec/3600;
    value2=deg2 + min2/60.0 + sec2/3600;
    display(value1)
    display(value2)
end