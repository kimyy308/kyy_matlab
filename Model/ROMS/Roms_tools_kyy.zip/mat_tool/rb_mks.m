function rb=rb_mks

load('rb.mat');


