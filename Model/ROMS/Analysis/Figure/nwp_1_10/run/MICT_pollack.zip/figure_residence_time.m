close all; clear all; clc;

system_name=computer;
if (strcmp(system_name,'PCWIN64'))
    % % for windows
    dropboxpath='C:\Users\KYY\Dropbox'; %% SNU_desktop, kyy_laptop
    addpath(genpath([dropboxpath '\source\matlab\Common\m_map']));
    addpath(genpath([dropboxpath '\source\matlab\Common\Figure']));
    addpath(genpath([dropboxpath '\source\matlab\Common\netcdf_old']));
    addpath(genpath([dropboxpath '\source\matlab\Model\ROMS\Grid_kyy']));
    addpath(genpath([dropboxpath '\source\matlab\Model\ROMS\Analysis\Figure\nwp_1_20\run']));

elseif (strcmp(system_name,'GLNXA64'))
    dropboxpath='/home/kimyy/Dropbox'; %% DAMO
    addpath(genpath([dropboxpath '/source/matlab/Common/m_map']));
    addpath(genpath([dropboxpath '/source/matlab/Common/Figure']));
    addpath(genpath([dropboxpath '/source/matlab/Common/netcdf_old']));
    addpath(genpath([dropboxpath '/source/matlab/Model/ROMS/Grid_kyy']));
    addpath(genpath([dropboxpath '/source/matlab/Model/ROMS/Analysis/Figure/nwp_1_20/run']));
end

warning off;
% % set calendar name
calendarname=cell(1,12); calendarname{1} = 'January'; calendarname{2} = 'February'; calendarname{3} = 'March'; calendarname{4} = 'April'; calendarname{5} = 'May'; calendarname{6} = 'June';
calendarname{7} = 'July'; calendarname{8} = 'August'; calendarname{9} = 'September'; calendarname{10} = 'October'; calendarname{11} = 'November'; calendarname{12} = 'December';

testname='nwp_1_10_EnOI';
% testname='avg_ens_10km_mean';

if (strcmp(testname,'avg_ens_10km_mean')==1)
    workdir=['/data1/kimyy/Model/LTRANS/LTRANSv2b/LTRANSv2b/output/seo_ens_mean/'];
else
    workdir=['/data1/kimyy/Model/LTRANS/LTRANSv2b/LTRANSv2b/output/',testname,'/'];
end

totmonth=1:3;
xlimday=90;
inputyear=1982:2001;
totmonth=1:3;
tind=1;
for yearij = 1:length(inputyear)
    tempyear = inputyear(yearij);
    ftime(tind) = datenum(tempyear,totmonth(1),15);
%         ftime(tind) = datenum(tempyear,totmonth(1),15) - datenum(1900,12,31);
    tind=tind+1;
end

% scalename={'e_folding', 'half', '2_3', 'tenth'};
% titlename={'37%(e-folding)','50%(half)','67%(2/3)','10%(1/10)'};

scalename={'e_folding'};
titlename={'37%(e-folding)'};

for scaleind=1:length(scalename)
    if (strcmp(testname,'avg_ens_10km_mean')==1)
        filename=['comb_res_time_',scalename{scaleind},'.mat']
    else
        filename=[testname,'_comb_res_time_',scalename{scaleind},'.mat']
    end
    load(filename);
    for nmonth=1:length(totmonth)
        month=totmonth(nmonth);
        figname=['D:\OneDrive - ������б�\MEPL\project\MICT_pollack\3rd_year\figure\',testname,'\LTRANS\residence_time\', ...
            scalename{scaleind},'_', num2str(month,'%04i'),'.jpg'];
        resplot=plot(ftime, squeeze(comb_res_time(inputyear(1)-inputyear(1)+1:inputyear(end)-inputyear(1)+1,month)) ,'color','k','Marker','o','MarkerFaceColor','k','MarkerSize',4)
        xlabel('year')
        ylabel('Residence time (day)')
        title(['(Residence time','-',titlename{scaleind},'-',calendarname{month},')'])
        set(gca,'YTick',(0:10:100));
        set(gca,'XTick',(ftime(1):366.0:ftime(end)));
        datetick('x','yy','keepticks')
        axis tight;
        ylim([0 100])
        set(resplot,'LineWidth',2);
        grid on
        set(gcf,'PaperPosition', [0 0 1.2*length(inputyear) 12]) 
        set(gca,'FontSize',13);
        saveas(gcf,figname,'jpg');
        grid off
    end
        figname=['D:\OneDrive - ������б�\MEPL\project\MICT_pollack\3rd_year\figure\',testname,'\LTRANS\residence_time\', ...
            scalename{scaleind},'_',num2str(inputyear(1),'%04i'),'_',num2str(inputyear(end),'%04i'),'_mean','.jpg'];
        resplot=plot(ftime, squeeze(mean(comb_res_time(inputyear(1)-inputyear(1)+1:inputyear(end)-inputyear(1)+1,:),2)) ,'color','k','Marker','o','MarkerFaceColor','k','MarkerSize',4)
        xlabel('year')
        ylabel('Residence time (day)')
        title(['(Residence time','-',titlename{scaleind},'-','Mean(Jan-Mar)',')'])
        set(gca,'YTick',(0:10:100));
        set(gca,'XTick',(ftime(1):366.0:ftime(end)));
        datetick('x','yy','keepticks')
        axis tight;
        ylim([0 100])
        set(resplot,'LineWidth',2);
        grid on
        set(gcf,'PaperPosition', [0 0 1.2*length(inputyear) 12]) 
        set(gca,'FontSize',13);
        saveas(gcf,figname,'jpg');
        grid off
end

% mean(mean(comb_res_time(16:20,:)))
