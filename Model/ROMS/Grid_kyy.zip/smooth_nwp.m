clear all
close all

romstools_param
warning off

% smoothname=['D:\MEPL\project\NWP\make_init\grid\roms_grid_combine2_smooth10.nc'];
rawname=['D:\MEPL\project\NWP\make_init\grid\roms_grid_combine2_edited_nwp_kyy.nc'];


disp(' ')
disp([' Start smoothing the grid: ',smoothname])
disp(' ')
disp([' Title: ',ROMS_title])
disp(' ')
disp([' Resolution: 1/',num2str(1/dl),' deg'])


%
%  Smooth the topography
%
% read not smoothed grid
nc2=netcdf('D:\MEPL\project\NWP\make_init\grid\roms_grid_combine2_not_smooth.nc','write');
h_raw=nc2{'h'}(:);
lon_rho=nc2{'lon_rho'}(:);
lat_rho=nc2{'lat_rho'}(:);
close(nc2);
nc3=netcdf(rawname);
h_0_8=nc3{'h'}(:);
close(nc3);

% % nc4=netcdf('D:\MEPL\project\NWP\make_init\grid\merged_etopo.nc');
% % h_merged=nc4{'depth_merged'}(:);
% % lon_merged=nc4{'lon'}(:);
% % lat_merged=nc4{'lat'}(:);
% % h_merged2 = griddata(lon_rho,lat_rho,h_merged,lon_merged,lat_merged);
% % close(nc4);

% load('D:\MEPL\project\NWP\KorBathy30s\etopo_merged.mat');
% depth_merged(find(depth_merged(:,:)<-10000))=depth_merged(find(depth_merged(:,:)<-10000))/1000.;
% lon_merged=xx;
% lat_merged=yy;
% h_merged =
% griddata(lon_merged,lat_merged,depth_merged,lon_rho(1,:),lat_rho(:,1));

nc4=netcdf('D:\MEPL\project\NWP\make_init\grid\merged_interp_roms.nc');
h_merged2=nc4{'H_MERGED4'}(:);
% lon_merged=nc4{'lon'}(:);
% lat_merged=nc4{'lat'}(:);
% h_merged2 = griddata(lon_rho,lat_rho,h_merged,lon_merged,lat_merged);
close(nc4);


nc=netcdf(smoothname,'write');
% h=nc{'h'}(:);
h=h_raw;
maskr=nc{'mask_rho'}(:);

% % for smooth 1
% h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
%              rtarget,n_filter_deep_topo,n_filter_final);

% % for smooth 2
% % % h(y,x)
% h1=h(1:200,1:200);
% h2=h(701:900,701:900);
% maskr1=maskr(1:200,1:200);
% maskr2=maskr(701:900,701:900);
% for i=1:5
% h1=smoothgrid(h1,maskr1,hmin,hmax_coast,hmax,...
%              rtarget,n_filter_deep_topo,n_filter_final);
% h2=smoothgrid(h2,maskr2,hmin,hmax_coast,hmax,...
%              rtarget,n_filter_deep_topo,n_filter_final);
% end
% h(1:200,1:200)=h1;
% h(701:900,701:900)=h2;

% % for smooth3         
% h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
%              rtarget,n_filter_deep_topo,n_filter_final);
% h(650:920,650:980)=h_0_95(650:920,650:980);

% % for smooth4         
% h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
%              rtarget,n_filter_deep_topo,n_filter_final);
% h(:,:)=h_0_95(:,:);

% % % % for smooth5     
% % rtarget=0.5;
% % h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
% %              rtarget,n_filter_deep_topo,n_filter_final);
% % for i=1:10
% %     rtarget=0.2
% %     h(1:170,1:250)=smoothgrid(h(1:170,1:250),maskr(1:170,1:250),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% %     h(701:920,701:980)=smoothgrid(h(701:920,701:980),maskr(701:920,701:980),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% %      h(701:800,701:850)=smoothgrid(h(701:800,701:850),maskr(701:800,701:850),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% % end

% % for smooth6     

% % h=h_merged2;
% % rtarget=0.5;
% % h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
% %              rtarget,n_filter_deep_topo,n_filter_final);
% % for i=1:10
% %     rtarget=0.2
% %     h(1:170,1:250)=smoothgrid(h(1:170,1:250),maskr(1:170,1:250),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% %     h(701:920,701:980)=smoothgrid(h(701:920,701:980),maskr(701:920,701:980),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% %      h(701:800,701:850)=smoothgrid(h(701:800,701:850),maskr(701:800,701:850),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% % end

% % % % for smooth7     
% % h=h_merged2;
% % % % korea strait
% % h(380:510,260:330)=h(380:510,260:330)+20;
% % h(420:480,330:380)=h(420:480,330:380)+20;
% % % % tsugaru strait
% % maskr(604,508)=1;  maskr(604,509)=1;
% % maskr(611,506)=1;  maskr(611,507)=1; maskr(611,508)=1;
% % maskr(612,520)=1;
% % maskr(611,519)=1;  maskr(611,520)=1; maskr(611,521)=1;
% % maskr(617,520)=1;  maskr(617,521)=1;
% % nc{'mask_rho'}(:) = maskr
% % h(590:620,500:530)=h(590:620,500:530)+20;
% % % % soya strait
% % h(715:735,533:546)=h(715:735,533:546)+20;
% % % % whole domain smoothing
% % rtarget=0.8;
% % h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
% %              rtarget,n_filter_deep_topo,n_filter_final);
% % % % oyashio
% % for i=1:5
% %     rtarget=0.2
% %     h(701:920,701:980)=smoothgrid(h(701:920,701:980),maskr(701:920,701:980),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% %      h(701:800,701:850)=smoothgrid(h(701:800,701:850),maskr(701:800,701:850),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % for i=1:3
% %     rtarget=0.2
% %     h(1:170,1:250)=smoothgrid(h(1:170,1:250),maskr(1:170,1:250),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % % % korea strait smoothing
% % rtarget=0.2
% % h(450:510,280:400)=smoothgrid(h(450:510,280:400),maskr(450:510,280:400),hmin,hmax_coast,hmax,...
% %                rtarget,n_filter_deep_topo,n_filter_final);
% % h(420:510,280:400)=smoothgrid(h(420:510,280:400),maskr(420:510,280:400),hmin,hmax_coast,hmax,...
% %                rtarget,n_filter_deep_topo,n_filter_final);
% % h(360:510,260:330)=smoothgrid(h(360:510,260:330),maskr(360:510,260:330),hmin,hmax_coast,hmax,...
% %                rtarget,n_filter_deep_topo,n_filter_final);



% % % % for smooth8
% % h=h_merged2;
% % % % korea strait
% % h(380:530,260:330)=h(380:530,260:330)+20;
% % h(420:480,330:380)=h(420:480,330:380)+20;
% % % % tsugaru strait
% % maskr(604,508)=1;  maskr(604,509)=1;
% % maskr(611,506)=1;  maskr(611,507)=1; maskr(611,508)=1;
% % maskr(612,520)=1;
% % maskr(611,519)=1;  maskr(611,520)=1; maskr(611,521)=1;
% % maskr(617,520)=1;  maskr(617,521)=1;
% % nc{'mask_rho'}(:) = maskr
% % h(590:620,500:530)=h(590:620,500:530)+20;
% % % % soya strait
% % h(715:735,533:546)=h(715:735,533:546)+20;
% % % % whole domain smoothing
% % rtarget=0.8;
% % h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
% %              rtarget,n_filter_deep_topo,n_filter_final);
% % % % oyashio
% % for i=1:5
% %     rtarget=0.2
% %     h(701:920,701:980)=smoothgrid(h(701:920,701:980),maskr(701:920,701:980),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% %      h(701:800,701:850)=smoothgrid(h(701:800,701:850),maskr(701:800,701:850),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % for i=1:3
% %     rtarget=0.2
% %     h(1:170,1:250)=smoothgrid(h(1:170,1:250),maskr(1:170,1:250),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % % % korea strait smoothing
% % rtarget=0.2
% % h(450:530,280:400)=smoothgrid(h(450:530,280:400),maskr(450:530,280:400),hmin,hmax_coast,hmax,...
% %                rtarget,n_filter_deep_topo,n_filter_final);
% % h(420:530,280:400)=smoothgrid(h(420:530,280:400),maskr(420:530,280:400),hmin,hmax_coast,hmax,...
% %                rtarget,n_filter_deep_topo,n_filter_final);
% % h(360:530,260:330)=smoothgrid(h(360:530,260:330),maskr(360:530,260:330),hmin,hmax_coast,hmax,...
% %                rtarget,n_filter_deep_topo,n_filter_final);
           
           

% % % % for smooth13
% % h=h_merged2;
% % 
% % % % tsugaru strait
% % maskr(604,508)=1;  maskr(604,509)=1;
% % maskr(611,506)=1;  maskr(611,507)=1; maskr(611,508)=1;
% % maskr(612,520)=1;
% % maskr(611,519)=1;  maskr(611,520)=1; maskr(611,521)=1;
% % maskr(617,520)=1;  maskr(617,521)=1;
% % nc{'mask_rho'}(:) = maskr
% % 
% % % % whole domain smoothing
% % rtarget=0.8;
% % h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
% %              rtarget,n_filter_deep_topo,n_filter_final);
% % % % oyashio
% % for i=1:1
% %     rtarget=0.2
% %     h(701:920,701:980)=smoothgrid(h(701:920,701:980),maskr(701:920,701:980),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% %      h(701:800,701:850)=smoothgrid(h(701:800,701:850),maskr(701:800,701:850),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % for i=1:5
% %     rtarget=0.2
% %     h(740:770,710:730)=smoothgrid(h(740:770,710:730),maskr(740:770,710:730),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% %      h(770:810,750:780)=smoothgrid(h(770:810,750:780),maskr(770:810,750:780),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% %      h(810:860,770:810)=smoothgrid(h(810:860,770:810),maskr(810:860,770:810),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% %       h(890:910,840:860)=smoothgrid(h(890:910,840:860),maskr(890:910,840:860),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % for i=1:1
% %     rtarget=0.2
% %     h(1:170,1:250)=smoothgrid(h(1:170,1:250),maskr(1:170,1:250),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % 
% % % % korea strait
% % h(380:510,260:330)=h(380:510,260:330)+20;
% % % % tsugaru strait
% % h(590:620,500:530)=h(590:620,500:530)+20;
% % % % soya strait
% % h(715:735,533:546)=h(715:735,533:546)+20;
% % % % kuroshio path
% % h(430:500,490:560)=h_raw(430:500,490:560);


% % % % for smooth13
% % 
% % % % tsugaru strait
% % maskr(604,508)=1;  maskr(604,509)=1;
% % maskr(611,506)=1;  maskr(611,507)=1; maskr(611,508)=1;
% % maskr(612,520)=1;
% % maskr(611,519)=1;  maskr(611,520)=1; maskr(611,521)=1;
% % maskr(617,520)=1;  maskr(617,521)=1;
% % nc{'mask_rho'}(:) = maskr
% % 
% % % % whole domain smoothing
% % rtarget=0.8;
% % h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
% %              rtarget,n_filter_deep_topo,n_filter_final);
% % % % oyashio
% % for i=1:1
% %     rtarget=0.2
% %     h(701:920,701:980)=smoothgrid(h(701:920,701:980),maskr(701:920,701:980),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% %      h(701:800,701:850)=smoothgrid(h(701:800,701:850),maskr(701:800,701:850),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % for i=1:5
% %     rtarget=0.2
% %     h(740:770,710:730)=smoothgrid(h(740:770,710:730),maskr(740:770,710:730),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% %      h(770:810,750:780)=smoothgrid(h(770:810,750:780),maskr(770:810,750:780),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% %      h(810:860,770:810)=smoothgrid(h(810:860,770:810),maskr(810:860,770:810),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% %       h(890:910,840:860)=smoothgrid(h(890:910,840:860),maskr(890:910,840:860),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % for i=1:1
% %     rtarget=0.2
% %     h(1:170,1:250)=smoothgrid(h(1:170,1:250),maskr(1:170,1:250),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % 
% % % % korea strait
% % h(380:510,260:330)=h(380:510,260:330)+20;
% % % % tsugaru strait
% % h(590:620,500:530)=h(590:620,500:530)+20;
% % % % soya strait
% % h(715:735,533:546)=h(715:735,533:546)+20;
% % % % kuroshio path
% % h(430:500,490:560)=h_raw(430:500,490:560);



% % % % for test17
% % 
% % % % tsugaru strait
% % maskr(604,508)=1;  maskr(604,509)=1;
% % maskr(611,506)=1;  maskr(611,507)=1; maskr(611,508)=1;
% % maskr(612,520)=1;
% % maskr(611,519)=1;  maskr(611,520)=1; maskr(611,521)=1;
% % maskr(617,520)=1;  maskr(617,521)=1;
% % nc{'mask_rho'}(:) = maskr
% % 
% % % % korea strait
% % h(380:510,260:330)=h(380:510,260:330)+20;
% % % % tsugaru strait
% % h(590:620,500:530)=h(590:620,500:530)+20;
% % % % soya strait
% % h(715:735,533:546)=h(715:735,533:546)+20;
% % 
% % 
% % % % korea strait smoothing
% % rtarget=0.2
% % h(450:530,280:400)=smoothgrid(h(450:530,280:400),maskr(450:530,280:400),hmin,hmax_coast,hmax,...
% %                rtarget,n_filter_deep_topo,n_filter_final);
% % h(420:530,280:400)=smoothgrid(h(420:530,280:400),maskr(420:530,280:400),hmin,hmax_coast,hmax,...
% %                rtarget,n_filter_deep_topo,n_filter_final);
% % h(360:530,260:330)=smoothgrid(h(360:530,260:330),maskr(360:530,260:330),hmin,hmax_coast,hmax,...
% %                rtarget,n_filter_deep_topo,n_filter_final);
% % 
% % % % oyashio
% % for i=1:1
% %     rtarget=0.2
% %     h(701:920,701:980)=smoothgrid(h(701:920,701:980),maskr(701:920,701:980),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% %      h(701:800,701:850)=smoothgrid(h(701:800,701:850),maskr(701:800,701:850),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % for i=1:5
% %     rtarget=0.2
% %     h(740:770,710:730)=smoothgrid(h(740:770,710:730),maskr(740:770,710:730),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% %      h(770:810,750:780)=smoothgrid(h(770:810,750:780),maskr(770:810,750:780),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% %      h(810:860,770:810)=smoothgrid(h(810:860,770:810),maskr(810:860,770:810),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% %       h(890:910,840:860)=smoothgrid(h(890:910,840:860),maskr(890:910,840:860),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % for i=1:1
% %     rtarget=0.2
% %     h(1:170,1:250)=smoothgrid(h(1:170,1:250),maskr(1:170,1:250),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % 
% % % % whole domain smoothing
% % rtarget=0.8;
% % h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
% %              rtarget,n_filter_deep_topo,n_filter_final);
% % 
% % % % kuroshio path
% % h(430:500,490:560)=h_raw(430:500,490:560);




% % % for test18
% 
% % % tsugaru strait
% maskr(604,508)=1;  maskr(604,509)=1;
% maskr(611,506)=1;  maskr(611,507)=1; maskr(611,508)=1;
% maskr(612,520)=1;
% maskr(611,519)=1;  maskr(611,520)=1; maskr(611,521)=1;
% maskr(617,520)=1;  maskr(617,521)=1;
% nc{'mask_rho'}(:) = maskr
% 
% % % korea strait
% h(380:510,260:330)=h(380:510,260:330)+25;
% % % tsugaru strait
% h(590:620,500:530)=h(590:620,500:530)+25;
% % % soya strait
% h(715:735,533:546)=h(715:735,533:546)+25;
% 
% 
% % % korea strait smoothing
% rtarget=0.2
% h(450:530,280:400)=smoothgrid(h(450:530,280:400),maskr(450:530,280:400),hmin,hmax_coast,hmax,...
%                rtarget,n_filter_deep_topo,n_filter_final);
% h(420:530,280:400)=smoothgrid(h(420:530,280:400),maskr(420:530,280:400),hmin,hmax_coast,hmax,...
%                rtarget,n_filter_deep_topo,n_filter_final);
% h(360:530,260:330)=smoothgrid(h(360:530,260:330),maskr(360:530,260:330),hmin,hmax_coast,hmax,...
%                rtarget,n_filter_deep_topo,n_filter_final);
% 
% % % oyashio
% for i=1:1
%     rtarget=0.2
%     h(701:920,701:980)=smoothgrid(h(701:920,701:980),maskr(701:920,701:980),hmin,hmax_coast,hmax,...
%                  rtarget,n_filter_deep_topo,n_filter_final);
%      h(701:800,701:850)=smoothgrid(h(701:800,701:850),maskr(701:800,701:850),hmin,hmax_coast,hmax,...
%      rtarget,n_filter_deep_topo,n_filter_final);
% end
% for i=1:5
%     rtarget=0.2
%     h(740:770,710:730)=smoothgrid(h(740:770,710:730),maskr(740:770,710:730),hmin,hmax_coast,hmax,...
%                  rtarget,n_filter_deep_topo,n_filter_final);
%      h(770:810,750:780)=smoothgrid(h(770:810,750:780),maskr(770:810,750:780),hmin,hmax_coast,hmax,...
%      rtarget,n_filter_deep_topo,n_filter_final);
%      h(810:860,770:810)=smoothgrid(h(810:860,770:810),maskr(810:860,770:810),hmin,hmax_coast,hmax,...
%      rtarget,n_filter_deep_topo,n_filter_final);
%       h(890:910,840:860)=smoothgrid(h(890:910,840:860),maskr(890:910,840:860),hmin,hmax_coast,hmax,...
%      rtarget,n_filter_deep_topo,n_filter_final);
% end
% for i=1:1
%     rtarget=0.2
%     h(1:170,1:250)=smoothgrid(h(1:170,1:250),maskr(1:170,1:250),hmin,hmax_coast,hmax,...
%                  rtarget,n_filter_deep_topo,n_filter_final);
% end
% 
% % % whole domain smoothing
% rtarget=0.5;
% h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
%              rtarget,n_filter_deep_topo,n_filter_final);
% h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
%              rtarget,n_filter_deep_topo,n_filter_final);
% h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
%              rtarget,n_filter_deep_topo,n_filter_final);
% % % kuroshio path
% h(430:500,490:560)=h_raw(430:500,490:560);



% % % % for test19
% % 
% % % % tsugaru strait
% % maskr(604,508)=1;  maskr(604,509)=1;
% % maskr(611,506)=1;  maskr(611,507)=1; maskr(611,508)=1;
% % maskr(612,520)=1;
% % maskr(611,519)=1;  maskr(611,520)=1; maskr(611,521)=1;
% % maskr(617,520)=1;  maskr(617,521)=1;
% % nc{'mask_rho'}(:) = maskr
% % 
% % % % korea strait
% % h(380:510,260:330)=h(380:510,260:330)+20;
% % % % tsugaru strait
% % h(590:620,500:530)=h(590:620,500:530)+0; % there are too much transport in the tsugaru strait and negative transport in the soya strait
% % % % soya strait
% % h(715:735,533:546)=h(715:735,533:546)+25;
% % 
% % 
% % % % korea strait smoothing
% % rtarget=0.2
% % h(450:530,280:400)=smoothgrid(h(450:530,280:400),maskr(450:530,280:400),hmin,hmax_coast,hmax,...
% %                rtarget,n_filter_deep_topo,n_filter_final);
% % h(420:530,280:400)=smoothgrid(h(420:530,280:400),maskr(420:530,280:400),hmin,hmax_coast,hmax,...
% %                rtarget,n_filter_deep_topo,n_filter_final);
% % h(360:530,260:330)=smoothgrid(h(360:530,260:330),maskr(360:530,260:330),hmin,hmax_coast,hmax,...
% %                rtarget,n_filter_deep_topo,n_filter_final);
% % 
% % % % oyashio
% % for i=1:1
% %     rtarget=0.2
% %     h(701:920,701:980)=smoothgrid(h(701:920,701:980),maskr(701:920,701:980),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% %      h(701:800,701:850)=smoothgrid(h(701:800,701:850),maskr(701:800,701:850),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % for i=1:5
% %     rtarget=0.2
% %     h(740:770,710:730)=smoothgrid(h(740:770,710:730),maskr(740:770,710:730),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% %      h(770:810,750:780)=smoothgrid(h(770:810,750:780),maskr(770:810,750:780),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% %      h(810:860,770:810)=smoothgrid(h(810:860,770:810),maskr(810:860,770:810),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% %       h(890:910,840:860)=smoothgrid(h(890:910,840:860),maskr(890:910,840:860),hmin,hmax_coast,hmax,...
% %      rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % for i=1:1
% %     rtarget=0.2
% %     h(1:170,1:250)=smoothgrid(h(1:170,1:250),maskr(1:170,1:250),hmin,hmax_coast,hmax,...
% %                  rtarget,n_filter_deep_topo,n_filter_final);
% % end
% % 
% % % % whole domain smoothing
% % rtarget=0.5;
% % h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
% %              rtarget,n_filter_deep_topo,n_filter_final);
% % % % kuroshio path
% % h(430:500,490:560)=h_raw(430:500,490:560);





% % for test23

% % tsugaru strait
% maskr(604,508)=1;  maskr(604,509)=1;
% maskr(611,506)=1;  maskr(611,507)=1; maskr(611,508)=1;
% maskr(612,520)=1;
% maskr(611,519)=1;  maskr(611,520)=1; maskr(611,521)=1;
% maskr(617,520)=1;  maskr(617,521)=1;
% nc{'mask_rho'}(:) = maskr

% % korea strait
h(380:510,260:330)=h(380:510,260:330)+10;
% % tsugaru strait
h(590:620,500:530)=h(590:620,500:530)+0; % there are too much transport in the tsugaru strait and negative transport in the soya strait
% % soya strait
h(715:735,533:546)=h(715:735,533:546)+25;


% % korea strait smoothing
rtarget=0.2
h(450:530,280:400)=smoothgrid(h(450:530,280:400),maskr(450:530,280:400),hmin,hmax_coast,hmax,...
               rtarget,n_filter_deep_topo,n_filter_final);
h(420:530,280:400)=smoothgrid(h(420:530,280:400),maskr(420:530,280:400),hmin,hmax_coast,hmax,...
               rtarget,n_filter_deep_topo,n_filter_final);
h(360:530,260:330)=smoothgrid(h(360:530,260:330),maskr(360:530,260:330),hmin,hmax_coast,hmax,...
               rtarget,n_filter_deep_topo,n_filter_final);

% % oyashio
for i=1:1
    rtarget=0.2
    h(701:920,701:980)=smoothgrid(h(701:920,701:980),maskr(701:920,701:980),hmin,hmax_coast,hmax,...
                 rtarget,n_filter_deep_topo,n_filter_final);
     h(701:800,701:850)=smoothgrid(h(701:800,701:850),maskr(701:800,701:850),hmin,hmax_coast,hmax,...
     rtarget,n_filter_deep_topo,n_filter_final);
end
for i=1:5
    rtarget=0.2
    h(740:770,710:730)=smoothgrid(h(740:770,710:730),maskr(740:770,710:730),hmin,hmax_coast,hmax,...
                 rtarget,n_filter_deep_topo,n_filter_final);
     h(770:810,750:780)=smoothgrid(h(770:810,750:780),maskr(770:810,750:780),hmin,hmax_coast,hmax,...
     rtarget,n_filter_deep_topo,n_filter_final);
     h(810:860,770:810)=smoothgrid(h(810:860,770:810),maskr(810:860,770:810),hmin,hmax_coast,hmax,...
     rtarget,n_filter_deep_topo,n_filter_final);
      h(890:910,840:860)=smoothgrid(h(890:910,840:860),maskr(890:910,840:860),hmin,hmax_coast,hmax,...
     rtarget,n_filter_deep_topo,n_filter_final);
end
for i=1:1
    rtarget=0.2
    h(1:170,1:250)=smoothgrid(h(1:170,1:250),maskr(1:170,1:250),hmin,hmax_coast,hmax,...
                 rtarget,n_filter_deep_topo,n_filter_final);
end

% % whole domain smoothing
rtarget=0.5;
h=smoothgrid(h,maskr,hmin,hmax_coast,hmax,...
             rtarget,n_filter_deep_topo,n_filter_final);
% % kuroshio path
h(430:500,490:560)=h_raw(430:500,490:560);





%
%  Write it down
%
disp(' ')
disp(' Write it down...')
nc{'h'}(:)=h;
close(nc);



% % 
% %  plot
% % 
% pcolor(h_0_8)
% shading interp
% figure;
% % pcolor(h(1:170,1:250))
% % pcolor(h(700:920,700:980))
% % pcolor(h(700:800,700:850))
% pcolor(h)
% shading interp