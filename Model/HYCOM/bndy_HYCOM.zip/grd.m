function grd = gg(location)

% if nargin == 0
%   location = 'eas'; % default
% end
%    scoord = [5 0.4 50 20];

switch location

    case 'NWP_1_20'
        vert_param
        grd_file ='/data1/kimyy/Model/HYCOM/hycom/GLBb/GLBb0.08_expt19.1_monthly/data/bndy_HYCOM/roms_grid_combine2_test37.nc' ;
        scoord = [7.0 2.0 250 40]; % theta_s theta_b hc N
        
        disp(' ')
        disp([ 'Loading ROMS grd for application: ' location])
        disp([ 'using grid file ' grd_file])
        disp(' ')
        grd = roms_get_grid(grd_file,scoord);
    
    case 'ES_1_40'
        vert_param
        grd_file ='/data1/kimyy/Model/HYCOM/hycom/GLBb/GLBb0.08_expt19.1_monthly/data/bndy_HYCOM/etopo1_Eastsea_40.nc' ;
        scoord = [7.0 2.0 250 40]; % theta_s theta_b hc N
        
        disp(' ')
        disp([ 'Loading ROMS grd for application: ' location])
        disp([ 'using grid file ' grd_file])
        disp(' ')
        grd = roms_get_grid(grd_file,scoord);    

        
end